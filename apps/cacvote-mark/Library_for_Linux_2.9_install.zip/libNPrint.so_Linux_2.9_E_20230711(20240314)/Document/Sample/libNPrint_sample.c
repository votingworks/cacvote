/*
 ============================================================================
 Name        : libNPrint_sample.c
 Author      : Nippon Printer Engnieering Inc.
 Version     : 2.7_20220914
 Copyright   : Nippon Printer Engnieering Inc.
 Description : Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>					// usleep

#include <time.h>					// localtime

#include "cv.h"						// for OpenCV2
#include "highgui.h"				// for OpenCV2

#define	N_SUCCESS					0
#define	N_ERR_OFFLINE				-5

#define IMG_RASTER_LINE				0x00
#define IMG_RASTER_BLOCK			0x01
#define IMG_RASTER_GRADATION		0x02
#define IMG_BITIMG					0x10

typedef void(*NCALLBACK)(char*, int, int, int);

int NEnumPrinters(char* o_printers, unsigned int* o_size);
int NOpenPrinter(char* i_prt, unsigned char i_statusFlg, NCALLBACK i_callback);
int NClosePrinter(char* i_prt);
int NPrint(char* i_prt, char* i_dat, unsigned int i_size, unsigned int* o_jobid);
int NDPrint(char* i_prt, unsigned char* i_dat, unsigned int i_size, unsigned int* o_jobid);
int NImagePrint(char* i_prt, unsigned char* i_bmp, unsigned int i_width, unsigned int i_height, unsigned int i_channels, unsigned int i_step, unsigned char i_putType, unsigned int* o_jobid);
int NImagePrintF(char* i_prt, char* i_bmp, unsigned char i_putType, unsigned int* o_jobid);
int NGetStatus(char* i_prt, unsigned long* o_status);
int NGetInformation(char* i_prt, unsigned char i_id, void* o_dat, unsigned long* o_time);
int NStartDoc(char* i_prt, unsigned int* o_jobid);
int NEndDoc(char* i_prt);
int NCancelDoc(char* i_prt);
unsigned long cputime();

int NImagePrintWrap(char* i_prt, IplImage* i_bmp, unsigned int i_width, unsigned int i_height, unsigned char i_putType, unsigned int* o_jobid);		// for OpenCV2

//***************************************************************************
//  Name : fncGetDate
//***************************************************************************
void fncGetDate(char *o_staData)
{
	time_t timep;
    struct tm *time_inf;
    char staDate[32];

    time(&timep);

    time_inf = localtime(&timep);
    memset(staDate, 0x00, 32);
    sprintf(staDate,"%02d/%02d/%04d %02d:%02d", time_inf->tm_mon + 1, time_inf->tm_mday, time_inf->tm_year + 1900, time_inf->tm_hour, time_inf->tm_min);
    memcpy(o_staData, staDate, strlen(staDate));
    return;
}

//---------------------------------------------------------------------------
//  Name     : fncTestSample
//  Deteail  : TEST Sample
//  Argument : Nothing
//  Return   : Nothing
//---------------------------------------------------------------------------
void fncTestSample(void)
{
	char staGetChr[8];
	char staPort[8];
	char staDate[32];
	unsigned char rawGScmd[8];
	unsigned char rawGetData[128];

	int nmsBit7Check;
	int flgBit7ChkLoop;
	int nmsRet;
	int nmsCnt;
	unsigned long nmuTimeout;
	unsigned long nmuTime;
	unsigned long nmuStatus;
	unsigned int nmuJob;
	unsigned int nmuGetJobID;
	unsigned int *pnmuID;
	unsigned int nmuDummy;


	char *staImgPath = "./PrintSample.bmp";
	IplImage *img = cvLoadImage(staImgPath, CV_LOAD_IMAGE_ANYCOLOR | CV_LOAD_IMAGE_ANYDEPTH);	// for OpenCV2
	nmuJob = 0;
	nmuDummy = 0;

	printf("********** Test Sample in **********\n");
	while(1)
	{
		memset(staPort, 0x00, 8);
		printf("*************************************\n");
		printf(" Please input port name(ex. PRT001):");
		scanf("%s", staPort);
		fflush(stdin);
		printf("*************************************\n");

		// ポートオープン
		// Port open
		nmsRet = NOpenPrinter(staPort, 1, NULL);
		printf(" NOpenPrinter           ReturnCode : %d\n", nmsRet);
		if(nmsRet != N_SUCCESS)
		{
			continue;
		}

		// print
		// 印刷
		while(1)
		{
			// 入力させる
			// Input
			memset(staGetChr, 0x00, 8);
			printf("*************************************\n");
			printf(" (R): receipt sample / (F): NImagePrintF test / (I): NImagePrint test / (E): end the print operation :");
			scanf("%s", staGetChr);
			fflush(stdin);
			printf("*************************************\n");

			// 印刷終了
			// end the print operation
			if(strcmp(staGetChr, "E") == 0 || strcmp(staGetChr, "e") == 0)
			{
				break;
			}
			else if(strcmp(staGetChr, "F") == 0 || strcmp(staGetChr, "f") == 0)
			{
				nmsRet = NPrint(staPort, "\"[NImagePrintF test]\"0A", strlen("\"[NImagePrintF test]\"0A"), NULL);
				nmsRet = NImagePrintF(staPort, staImgPath, IMG_RASTER_BLOCK, NULL);

				// フィード＆カット
				// Feed / Cut command
				nmsRet = NPrint(staPort, "1b4aff1b69", strlen("1b4aff1b69"), NULL);

				continue;
			}
			else if(strcmp(staGetChr, "I") == 0 || strcmp(staGetChr, "i") == 0)
			{
				nmsRet = NPrint(staPort, "\"[NImagePrint test]\"0A", strlen("\"[NImagePrint test]\"0A"), NULL);
				nmsRet = NImagePrintWrap(staPort, img, img->width, img->height, IMG_RASTER_BLOCK, NULL);
				
				// フィード＆カット
				// Feed / Cut command
				nmsRet = NPrint(staPort, "1b4aff1b69", strlen("1b4aff1b69"), NULL);

				continue;
			}
			else if(strcmp(staGetChr, "R") == 0 || strcmp(staGetChr, "r") == 0)
			{
				// receipt sample
			}
			else
			{
				printf("Wrong input. Please try again.\n");
				continue;
			}





			// 年月日、時間取得
			// get a date
			memset(staDate, 0x00, 32);
			strcat(staDate, "\"DATE : ");
			fncGetDate(&staDate[strlen(staDate)]);
			strcat(staDate, "\"");

			// 状態確認
			// Printer status check
			nmsRet = NGetStatus(staPort, &nmuStatus);
			printf(" NGetStatus             ReturnCode : %d -> Status           : %02lX\n", nmsRet, nmuStatus);
			if(nmsRet != N_SUCCESS)
			{
				continue;
			}

			// 情報取得CMD発行
			// Information acquisition command output
			nmsRet = NPrint(staPort, "1b73021b73031b7304", strlen("1b73021b73031b7304"), NULL);
			usleep(1000000);
			// Model name
			memset(rawGetData, 0x00, 128);
			nmsRet = NGetInformation(staPort, (unsigned char)0x02, rawGetData, &nmuTime);
			printf(" NGetInformation(ID:02) ReturnCode : %d -> Model Name       : %s\n", nmsRet, rawGetData);
			// Firmware version
			memset(rawGetData, 0x00, 128);
			nmsRet = NGetInformation(staPort, (unsigned char)0x03, rawGetData, &nmuTime);
			printf(" NGetInformation(ID:03) ReturnCode : %d -> Firmware Version : %s\n", nmsRet, rawGetData);
			// Boot version
			memset(rawGetData, 0x00, 128);
			nmsRet = NGetInformation(staPort, (unsigned char)0x04, rawGetData, &nmuTime);
			printf(" NGetInformation(ID:04) ReturnCode : %d -> Boot Version     : %s\n", nmsRet, rawGetData);

			//
			// データセット
			// Set data
			//

			// 印字開始CMD
			// In printing command
			nmuJob++;
			flgBit7ChkLoop = 1;

			for(nmsBit7Check = 0; nmsBit7Check < 2 && flgBit7ChkLoop == 1; nmsBit7Check++)
			{
				memset(rawGScmd, 0x00, 8);
				rawGScmd[0] = 0x1d;
				rawGScmd[1] = 0x47;
		
				if(nmsBit7Check == 0)
				{
					// pattern1
					rawGScmd[2] = 0x11;
				}
				else if(nmsBit7Check == 1)
				{
					// pattern2
					rawGScmd[2] = 0x31;
				}

				memcpy((unsigned long*)&rawGScmd[3], &nmuJob, 4);
				nmsCnt = 7;
				nmsRet = NDPrint(staPort, rawGScmd, nmsCnt, NULL);

				// ステータスのBit7確認
				// Bit 7 confirmation of status
				nmuTimeout = cputime();
				while(1)
				{
					if(NGetStatus(staPort, &nmuStatus) < 0x00)
					{
						printf(" Bit7:ON		OK...\n");
						break;
					}

					if((nmuStatus & 0x80) == 0x80)
					{
						printf(" Bit7:ON		OK...\n");
						flgBit7ChkLoop = 0;
						break;
					}

					if(cputime() > (nmuTimeout+5000))
					{
						if(nmsBit7Check == 0)
						{
							printf(" 1D 47 11 command error -> Try 1D 47 31\n");
						}
						else if(nmsBit7Check == 1)
						{
							printf(" ***** Timeout:Bit7 did not turn ON. *****\n");
						}
						break;
					}
				}

			}

			// StartDoc
			nmsRet = NStartDoc(staPort, &nmuDummy);
			printf(" NStartDoc              ReturnCode : %d -> JOB ID : %d\n", nmsRet, nmuDummy);
			if(nmsRet != N_SUCCESS)
			{
				continue;
			}

			// 文字データ
			// other data
			nmsRet = NPrint(staPort, "1b61011b2130", strlen("1b61011b2130"), NULL);
			nmsRet = NPrint(staPort, "\"PRIMEX\"0a", strlen("\"PRIMEX\"0a"), NULL);
			nmsRet = NPrint(staPort, "1b2100", strlen("1b2100"), NULL);
			nmsRet = NPrint(staPort, "\"---- demo ----\"0a", strlen("\"---- demo ----\"0a"), NULL);
			nmsRet = NPrint(staPort, "1b6100", strlen("1b6100"), NULL);

			nmsRet = NPrint(staPort, "\"1-5-12, Unoki, Ohtaku, Tokyo\"0a", strlen("\"1-5-12, Unoki, Ohtaku, Tokyo\"0a"), NULL);
			nmsRet = NPrint(staPort, "\"146-8650 Japan\"0a", strlen("\"146-8650 Japan\"0a"), NULL);
			nmsRet = NPrint(staPort, "\"TEL    : 81-3-3750-5817\"0a", strlen("\"TEL    : 81-3-3750-5817\"0a"), NULL);
			nmsRet = NPrint(staPort, "\"E-Mail : overseas@primex.co.jp\"0a", strlen("\"E-Mail : overseas@primex.co.jp\"0a"), NULL);
			nmsRet = NPrint(staPort, "\"********************************\"0a", strlen("\"********************************\"0a"), NULL);
			nmsRet = NPrint(staPort, "1b6101", strlen("1b6101"), NULL);
			nmsRet = NPrint(staPort, "\"This is a test receipt\"0a", strlen("\"This is a test receipt\"0a"), NULL);
			nmsRet = NPrint(staPort, "1b6100", strlen("1b6100"), NULL);
			nmsRet = NPrint(staPort, "\"********************************\"0a", strlen("\"********************************\"0a"), NULL);
			nmsRet = NPrint(staPort, staDate, strlen(staDate), NULL);
			nmsRet = NPrint(staPort, "0a", strlen("0a"), NULL);
			nmsRet = NPrint(staPort, "\"Charge : Primex\"0a0a", strlen("\"Charge : Primex\"0a0a"), NULL);
			nmsRet = NPrint(staPort, "\"Coke\"0a", strlen("\"Coke\"0a"), NULL);
			nmsRet = NPrint(staPort, "\"    $ 2.00 * 3            $ 6.00\"0a", strlen("\"    $ 2.00 * 3            $ 6.00\"0a"), NULL);
			nmsRet = NPrint(staPort, "\"Apple juice\"0a", strlen("\"Apple juice\"0a"), NULL);
			nmsRet = NPrint(staPort, "\"    $ 2.00 * 1            $ 2.00\"0a", strlen("\"    $ 2.00 * 1            $ 2.00\"0a"), NULL);
			nmsRet = NPrint(staPort, "\"Budweiser\"0a", strlen("\"Budweiser\"0a"), NULL);
			nmsRet = NPrint(staPort, "\"    $ 5.00 * 1            $ 5.00\"0a", strlen("\"    $ 5.00 * 1            $ 5.00\"0a"), NULL);
			nmsRet = NPrint(staPort, "\"Whisky\"0a", strlen("\"Whisky\"0a"), NULL);
			nmsRet = NPrint(staPort, "\"   $ 10.00 * 1           $ 10.00\"0a", strlen("\"   $ 10.00 * 1           $ 10.00\"0a"), NULL);
			nmsRet = NPrint(staPort, "\"--------------------------------\"0a", strlen("\"--------------------------------\"0a"), NULL);
			nmsRet = NPrint(staPort, "\"TOTAL                 USD  23.00\"0a", strlen("\"TOTAL                 USD  23.00\"0a"), NULL);
			nmsRet = NPrint(staPort, "\"--------------------------------\"0a", strlen("\"--------------------------------\"0a"), NULL);
			nmsRet = NPrint(staPort, "\"Deposit               USD  30.00\"0a", strlen("\"Deposit               USD  30.00\"0a"), NULL);
			nmsRet = NPrint(staPort, "\"Change                USD   7.00\"0a0a", strlen("\"Change                USD   7.00\"0a0a"), NULL);
			// Barcode
			nmsRet = NPrint(staPort, "1b61011d4802", strlen("1b61011d4802"), NULL);
			// CODE39
			nmsRet = NPrint(staPort, "1d6b04\"*12345*\"000a", strlen("1d6b04\"*12345*\"000a"), NULL);
			// バーコード(設定値解除)
			// Barcode(Setting release)
			nmsRet = NPrint(staPort, "1d48001b6100", strlen("1d48001b6100"), NULL);
			nmsRet = NPrint(staPort, "\"https://www.primex.co.jp/en/\"0a", strlen("\"https://www.primex.co.jp/en/\"0a"), NULL);
			
			// フィード＆カット
			// Feed / Cut command
			nmsRet = NPrint(staPort, "1b4aff1b69", strlen("1b4aff1b69"), NULL);

			// 印字終了CMD
			// Out printing command
			if(nmsBit7Check == 1)
			{
				printf(" Print end command : 1D4710\n");
				nmsRet = NPrint(staPort, "1d4710", strlen("1d4710"), NULL);
			}
			else
			{
				printf(" Print end command : 1D4730\n");
				nmsRet = NPrint(staPort, "1d4730", strlen("1d4730"), NULL);
			}

			// EndDoc
			nmsRet = NEndDoc(staPort);
			printf(" NEndDoc                ReturnCode : %d\n", nmsRet);
			if(nmsRet != N_SUCCESS)
			{
				nmsRet = NCancelDoc(staPort);
				printf(" NCancelDoc             ReturnCode : %d\n", nmsRet);
				continue;
			}


			// 印刷完了待ち
			// It waits until printing is completed.
			nmuGetJobID = 0;
			nmuTimeout = cputime();
			while(nmuGetJobID != nmuJob)
			{
				memset(rawGetData, 0x00, 128);
				nmsRet = NGetInformation(staPort, (unsigned char)19, rawGetData, &nmuTime);
				pnmuID = (unsigned int*)&rawGetData;
				nmuGetJobID = *pnmuID;

				if(cputime() > (nmuTimeout + 10000))
				{
					printf(" ***** Timeout Get JobID Error(ID:19) *****\n");
					break;
				}

				usleep(50000);
			}
			if(nmuGetJobID == nmuJob)
			{
				printf(" ID:19 GetJobID:%d\n", nmuGetJobID);
				printf(" Print Success\n");
			}
		}

		// ポートクローズ
		// port close
		nmsRet = NClosePrinter(staPort);
		printf(" NClosePrinter          ReturnCode : %d\n", nmsRet);


		memset(staGetChr, 0x00, 8);
		printf("*************************************\n");
		printf(" Do you \"Test Sample\" quit?(YES:y or Y / NO:n or N):");
		scanf("%s", staGetChr);
		fflush(stdin);

		// 終了
		// Exit
		if(strcmp(staGetChr, "Y") == 0 || strcmp(staGetChr, "y") == 0)
		{
			break;
		}

	}
	printf("********** Test Sample out **********\n");

	cvReleaseImage(&img);

	return;
}

//***************************************************************************
//  Name : main
//***************************************************************************
int main(void)
{
	int nmsRet;
	char staSelect[8];
	char *pPrinters;
	unsigned int nmuSize;
	unsigned int nmuDummy;

	printf("---------- libNPrint.so Test Sample Start ----------\n");
	while(1)
	{
		// 入力させる
		// Input
		memset(staSelect, 0x00, 8);
		printf("Please select( (A or a):NEnumPrinters / (B or b):Test Sample / Other:quit ):");
		scanf("%s", staSelect);
		fflush(stdin);

		if(strcmp(staSelect, "A") == 0 || strcmp(staSelect, "a") == 0)
		{
			nmuSize = 0;
			nmsRet = NEnumPrinters(NULL, &nmuSize);
			printf("NEnumPrinters(ret:%d)\n", nmsRet);
			if(nmuSize != 0)
			{
				pPrinters = (char*)malloc(sizeof(char)*(nmuSize+1));
				memset(pPrinters, 0x00, sizeof(char)*(nmuSize+1));
				NEnumPrinters(pPrinters, &nmuDummy);
				printf("%s\n", pPrinters);
				free(pPrinters);
			}
		}
		else if(strcmp(staSelect, "B") == 0 || strcmp(staSelect, "b") == 0)
		{
			fncTestSample();
		}
		else
		{
			break;	// Exit
		}
	}
	printf("---------- libNPrint.so Test Sample End ----------\n");
	return EXIT_SUCCESS;
}

//---------------------------------------------------------------------------
//  Name     : NImagePrintWrap
//  Detail   : Ver2.0以降のNImagePrint用のラッパー関数（for OpenCV2）
//             Wrapper function for NImagePrint after Ver2.0（for OpenCV2）
//  Argument : i_prt     : Printer name
//			　 i_bmp     : Image(OpenCV element)
//			　 i_width   : Image width
//			　 i_height  : Image height
//			　 i_putType : Output type
//						 :	0x00：Raster Line
//						 :  0x01：Raster Block
//						 :  0x02：Raster Block Gradation
//						 :  0x10：Bit image
//      	   o_jobid   : Print job id（Null can be specified）
//  Return   : Return value of NImagePrint
//---------------------------------------------------------------------------
int NImagePrintWrap(char* i_prt, IplImage* i_bmp, unsigned int i_width, unsigned int i_height, unsigned char i_putType, unsigned int* o_jobid)
{
	int ret = N_SUCCESS;
	int channels = i_bmp->nChannels;			// Channel count of Image
	int step = i_bmp->widthStep;				// Step count of Image
	unsigned char* bufImage = i_bmp->imageData;	// Data array of Image

	ret = NImagePrint(i_prt, bufImage, i_width, i_height, channels, step, i_putType, o_jobid);

	return ret;
}
